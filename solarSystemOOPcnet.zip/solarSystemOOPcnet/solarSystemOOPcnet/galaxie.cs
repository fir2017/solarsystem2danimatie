﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace solarSystemOOPcnet
{
    public class galaxie
    {
        public string denumire;
        public pozitie pozitia;
        public dimensiune dimensiunea;
        public stil stilul;

        public List<sistemsolar> sistemesolare = new List<sistemsolar>();
        public orbita orbite;
    }
}
