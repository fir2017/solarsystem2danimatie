﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace solarSystemOOPcnet
{
    public class planetapitica
    {
        public string denumire;
        public pozitie pozitia;
        public dimensiune dimensiunea;
        public stil stilul;

        public List<satelit> sateliti = new List<satelit>();
        public orbita orbite;

        List<inel> inele = new List<inel>();
    }
}
