﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace solarSystemOOPcnet
{
    public class pozitie
    {
        public float x;
        public float y;
        public float z;
    }
}
