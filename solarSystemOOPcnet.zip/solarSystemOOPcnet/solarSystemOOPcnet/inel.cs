﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace solarSystemOOPcnet
{
    public class inel
    {
        public string denumire;
        public pozitie pozitia;
        public dimensiune dimensiunea;
        public stil stilul;
    }
}
