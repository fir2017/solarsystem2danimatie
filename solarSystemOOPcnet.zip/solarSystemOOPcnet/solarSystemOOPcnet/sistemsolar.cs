﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace solarSystemOOPcnet
{
    public class sistemsolar
    {
        public string denumire;
        public pozitie pozitia;
        public dimensiune dimensiunea;
        public stil stilul;

        public List<stea> stele = new List<stea>();
        public List<planeta> planete = new List<planeta>();
        public List<planetapitica> planetepitice = new List<planetapitica>();
        public List<asteroid>  asteorizi= new List<asteroid>();
        public List<centura> centuri = new List<centura>();
        public List<cometa>  comete= new List<cometa>();
        public List<meteorit>  meteoriti= new List<meteorit>();

        public orbita orbite;


    }
}
