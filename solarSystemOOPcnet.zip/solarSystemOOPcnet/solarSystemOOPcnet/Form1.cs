﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace solarSystemOOPcnet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public multivers multiversulNostru = new multivers();
        
        private void Form1_Load(object sender, EventArgs e)
        {
            multiversulNostru.universuri.Add(new univers());

            multiversulNostru.universuri[0].denumire = "universulNostru";
            multiversulNostru.universuri[0].galaxi.Add(new galaxie());
            multiversulNostru.universuri[0].galaxi[0].denumire = "calea lactee";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare.Add(new sistemsolar());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].denumire = "sistemul solar";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].stele.Add(new stea());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].stele[0].denumire = "soare";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete.Add(new planeta());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete[0].denumire = "mercur";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete.Add(new planeta());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete[1].denumire = "venus";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete.Add(new planeta());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete[2].denumire = "pamant";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete.Add(new planeta());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete[3].denumire = "marte";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete.Add(new planeta());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete[4].denumire = "jupiter";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete.Add(new planeta());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete[5].denumire = "saturn";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete.Add(new planeta());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete[6].denumire = "uranus";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete.Add(new planeta());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planete[7].denumire = "neptun";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planetepitice.Add(new planetapitica());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planetepitice[0].denumire = "ceres";
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planetepitice.Add(new planetapitica());
            multiversulNostru.universuri[0].galaxi[0].sistemesolare[0].planetepitice[1].denumire = "pluto";


        }
    }
}
