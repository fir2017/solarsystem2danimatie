﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace solarSystemOOPcnet
{
    public class stil
    {
        public Color culoare;
        public Font fontul;
        public Color Background ;
        public Color Foreground;
    }
}
