﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace solarSystemOOPcnet
{
    public class cometa
    {
        public string denumire;
        public pozitie pozitia;
        public dimensiune dimensiunea;
        public stil stilul;
        public orbita orbite;
    }
}
